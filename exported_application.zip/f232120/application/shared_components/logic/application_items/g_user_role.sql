prompt --application/shared_components/logic/application_items/g_user_role
begin
--   Manifest
--     APPLICATION ITEM: G_USER_ROLE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>8182019604255331
,p_default_application_id=>109
,p_default_id_offset=>125859130612030084474
,p_default_owner=>'WKSP_PKWORKSPACE'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(11282082536619252)
,p_name=>'G_USER_ROLE'
,p_scope=>'GLOBAL'
,p_protection_level=>'I'
,p_version_scn=>39442728097432
);
wwv_flow_imp.component_end;
end;
/
