prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>8182019604255331
,p_default_application_id=>109
,p_default_id_offset=>125859130612030084474
,p_default_owner=>'WKSP_PKWORKSPACE'
);
wwv_flow_imp_page.create_page(
 p_id=>5
,p_name=>'Quick Data Loader'
,p_alias=>'QUICK-DATA-LOADER'
,p_page_mode=>'MODAL'
,p_step_title=>'Quick Data Loader'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>2100407606326202693
,p_page_template_options=>'#DEFAULT#'
,p_dialog_width=>'65%'
,p_dialog_resizable=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'23'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9617116954043808)
,p_plug_name=>'hide'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>60
,p_location=>null
,p_plug_display_condition_type=>'NEVER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10752352303440708)
,p_plug_name=>'Employee Data Help'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span class="excel-help-tooltip">',
'    <i class="fa fa-question-circle-o"></i>',
'    <div class="excel-popup">',
'        <div class="excel-popup-header">',
unistr('            <span>\D83D\DCCA</span>'),
'            Excel File Format Requirements',
'        </div>',
'        <div class="excel-popup-body">',
'            <table class="excel-table">',
'                <thead>',
'                    <tr>',
'                        ',
'                        <th>Field Name</th>',
'                    ',
'                    </tr>',
'                </thead>',
'                <tbody>',
'                    <tr>',
'                        ',
'                        <td>EmployeeID</td>',
'                     ',
'                    </tr>',
'                    <tr>',
'                    ',
'                        <td>EmpName</td>',
'                   ',
'                    </tr>',
'                    <tr>',
'                        ',
'                        <td>Designation</td>',
'                      ',
'                    </tr>',
'                    <tr>',
'                     ',
'                        <td>Grade</td>',
'               ',
'                    </tr>',
'                    <tr>',
'                  ',
'                        <td>Competency</td>',
'                     ',
'                    </tr>',
'                    <tr>',
'                     ',
'                        <td>TotalAnnualCTC</td>',
'                     ',
'                    </tr>',
'					<tr>',
'                     ',
'                        <td>BillRate</td>',
'                     ',
'                    </tr>',
'                </tbody>',
'            </table>',
'          ',
'        </div>',
'    </div>',
'</span>',
'',
'',
'<style>.apex-help-tooltip {',
'    position: relative;',
'    display: inline-block;',
'    margin-left: 8px;',
'    cursor: help;',
'}',
'',
'.apex-help-tooltip i {',
'    color: #0572CE;',
'    font-size: 16px;',
'    transition: color 0.2s ease;',
'}',
'',
'.apex-help-tooltip:hover i {',
'    color: #054C7A;',
'}',
'',
'/* Excel-style tooltip */',
'.apex-help-tooltip::after {',
'    content: attr(title);',
'    position: absolute;',
'    top: -10px;',
'    left: 25px;',
'    min-width: 250px;',
'    max-width: 300px;',
'    padding: 0;',
'    background: white;',
'    border: 1px solid #D4D4D4;',
'    border-radius: 4px;',
'    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);',
'    font-family: ''Segoe UI'', Tahoma, Geneva, Verdana, sans-serif;',
'    font-size: 12px;',
'    line-height: 1.4;',
'    color: #333;',
'    z-index: 1000;',
'    opacity: 0;',
'    visibility: hidden;',
'    transition: opacity 0.3s ease, visibility 0.3s ease;',
'    white-space: pre-line;',
'}',
'',
'/* Excel header bar */',
'.apex-help-tooltip::before {',
unistr('    content: "\D83D\DCCA Excel File Format";'),
'    position: absolute;',
'    top: -10px;',
'    left: 25px;',
'    min-width: 250px;',
'    max-width: 300px;',
'    padding: 8px 12px;',
'    background: linear-gradient(135deg, #217346 0%, #0F5132 100%);',
'    color: white;',
'    font-family: ''Segoe UI'', Tahoma, Geneva, Verdana, sans-serif;',
'    font-size: 13px;',
'    font-weight: 600;',
'    border-top-left-radius: 4px;',
'    border-top-right-radius: 4px;',
'    border-bottom: 1px solid #D4D4D4;',
'    z-index: 1001;',
'    opacity: 0;',
'    visibility: hidden;',
'    transition: opacity 0.3s ease, visibility 0.3s ease;',
'}',
'',
'/* Show tooltip on hover */',
'.apex-help-tooltip:hover::after,',
'.apex-help-tooltip:hover::before {',
'    opacity: 1;',
'    visibility: visible;',
'}',
'',
'/* Custom content styling for Excel-like appearance */',
'.excel-tooltip-content {',
'    padding: 12px;',
'    background: white;',
'}',
'',
'/* Alternative: More detailed Excel-style tooltip */',
'.excel-help-tooltip {',
'    position: relative;',
'    display: inline-block;',
'    margin-left: 8px;',
'    cursor: help;',
'}',
'',
'.excel-help-tooltip i {',
'    color: #0572CE;',
'    font-size: 16px;',
'    transition: color 0.2s ease;',
'}',
'',
'.excel-help-tooltip:hover i {',
'    color: #054C7A;',
'}',
'',
'.excel-help-tooltip .excel-popup {',
'    position: absolute;',
'    top: -10px;',
'    left: 25px;',
'    min-width: 190px;',
'    background: white;',
'    border: 1px solid #D4D4D4;',
'    border-radius: 6px;',
'    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);',
'    opacity: 0;',
'    visibility: hidden;',
'    transition: opacity 0.3s ease, visibility 0.3s ease;',
'    z-index: 1000;',
'    font-family: ''Segoe UI'', Tahoma, Geneva, Verdana, sans-serif;',
'}',
'',
'.excel-help-tooltip:hover .excel-popup {',
'    opacity: 1;',
'    visibility: visible;',
'}',
'',
'.excel-popup-header {',
'    background: linear-gradient(135deg, #217346 0%, #0F5132 100%);',
'    color: white;',
'    padding: 10px 15px;',
'    border-top-left-radius: 5px;',
'    border-top-right-radius: 5px;',
'    font-weight: 600;',
'    font-size: 14px;',
'    display: flex;',
'    align-items: center;',
'    gap: 8px;',
'}',
'',
'.excel-popup-body {',
'    padding: 15px;',
'}',
'',
'.excel-table {',
'    width: 100%;',
'    border-collapse: collapse;',
'    margin-top: 8px;',
'    font-size: 12px;',
'}',
'',
'.excel-table th {',
'    background: #F2F2F2;',
'    border: 1px solid #D4D4D4;',
'    padding: 6px 10px;',
'    text-align: center;',
'    font-weight: 600;',
'    color: #333;',
'    font-size: 11px;',
'}',
'',
'.excel-table td {',
'    border: 1px solid #D4D4D4;',
'    padding: 6px 10px;',
'    text-align: left;',
'    background: white;',
'    color: #333;',
'}',
'',
'.excel-note {',
'    margin-top: 10px;',
'    padding: 8px;',
'    background: #FFF3CD;',
'    border: 1px solid #FFEAA7;',
'    border-radius: 4px;',
'    font-size: 11px;',
'    color: #856404;',
'}',
'',
'/* Arrow pointer */',
'.excel-popup::before {',
'    content: '''';',
'    position: absolute;',
'    top: 20px;',
'    left: -8px;',
'    width: 0;',
'    height: 0;',
'    border-top: 8px solid transparent;',
'    border-bottom: 8px solid transparent;',
'    border-right: 8px solid #D4D4D4;',
'}',
'',
'.excel-popup::after {',
'    content: '''';',
'    position: absolute;',
'    top: 21px;',
'    left: -7px;',
'    width: 0;',
'    height: 0;',
'    border-top: 7px solid transparent;',
'    border-bottom: 7px solid transparent;',
'    border-right: 7px solid white;</style>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18759281588189815)
,p_plug_name=>'Employees'
,p_region_name=>'my_region'
,p_icon_css_classes=>'fa-dataset'
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--hideHeader js-addHiddenHeadingRoleDesc'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2072724515482255512
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'   ''Employee Data''  AS card_title,',
'   ''Upload Compensation & Billing Data '' AS card_text,',
'   ''fas fa-user-tie''       AS card_icon, -- Font Awesome icon',
'   ''f?p=&APP_ID.:11:&SESSION.'' AS card_link',
'',
'FROM dual;',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(9638814475293505)
,p_region_id=>wwv_flow_imp.id(18759281588189815)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'CARD_TITLE'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'CARD_TEXT'
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'STATIC_CLASS'
,p_icon_css_classes=>'fa-user-arrow-up'
,p_icon_position=>'START'
,p_media_adv_formatting=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(9639331220293508)
,p_card_id=>wwv_flow_imp.id(9638814475293505)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18761031451192370)
,p_plug_name=>'Timesheet'
,p_icon_css_classes=>'fa-coins'
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2072724515482255512
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'   ''Timesheet Submission''  AS card_title,',
'   ''Work Hours & Project Allocation'' AS card_text,',
'   ''fas fa-clock''          AS card_icon, -- Font Awesome icon',
'   ''f?p=&APP_ID.:12:&SESSION.'' AS card_link',
'FROM dual;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(9640215573296049)
,p_region_id=>wwv_flow_imp.id(18761031451192370)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'CARD_TITLE'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'CARD_TEXT'
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'STATIC_CLASS'
,p_icon_css_classes=>'fa-timeline'
,p_icon_position=>'START'
,p_media_adv_formatting=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(9640781953296051)
,p_card_id=>wwv_flow_imp.id(9640215573296049)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18762217325193971)
,p_plug_name=>'Project'
,p_title=>'Project'
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2072724515482255512
,p_plug_display_sequence=>40
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'   ''Project Data Upload''  AS card_title,',
'   ''Project Revenue & Scope Data'' AS card_subtitle,',
'   ''Pending Review''       AS card_text,',
'   ''f?p=&APP_ID.:13:&SESSION.'' AS card_link',
'FROM dual;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(9641686886297652)
,p_region_id=>wwv_flow_imp.id(18762217325193971)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'CARD_TITLE'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'CARD_SUBTITLE'
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'STATIC_CLASS'
,p_icon_css_classes=>'fa-strategy'
,p_icon_position=>'START'
,p_media_adv_formatting=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(9642144232297654)
,p_card_id=>wwv_flow_imp.id(9641686886297652)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9307848270911330)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(9617116954043808)
,p_button_name=>'Upload_Employees'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Upload Employees'
,p_button_redirect_url=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:::'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9307045542911327)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(9617116954043808)
,p_button_name=>'Upload_Project'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Upload Project'
,p_button_redirect_url=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:::'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9307453508911329)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(9617116954043808)
,p_button_name=>'Upload_Timesheets'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Upload Timesheets'
,p_button_redirect_url=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:::'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp.component_end;
end;
/
