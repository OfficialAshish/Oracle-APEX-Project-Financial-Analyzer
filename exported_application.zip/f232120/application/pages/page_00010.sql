prompt --application/pages/page_00010
begin
--   Manifest
--     PAGE: 00010
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>8182019604255331
,p_default_application_id=>109
,p_default_id_offset=>125859130612030084474
,p_default_owner=>'WKSP_PKWORKSPACE'
);
wwv_flow_imp_page.create_page(
 p_id=>10
,p_name=>'Oracle Dashboard'
,p_alias=>'DASHBOARD'
,p_step_title=>'Oracle Dashboard'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.my-bg {',
'  width: 200px;   /* image ki width */',
'  height: auto;   /* proportion maintain rahega */',
'  display: block; /* image ko block banata hai (center alignment ke liye useful) */',
'  margin: 0 auto; /* center align karne ke liye */',
'}',
' '))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9303770961756369)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle:t-Form--labelsAbove:t-Region-orderBy--center'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="erp-banner">',
'  <img src="#APP_FILES#img/ggi_5x98b45x98b45x98.png" alt="Gross Margin Calculator Dashboard">',
'</div>',
'',
'<style>',
'.t-Header-nav {',
'  display: block;',
'}',
'',
'.t-Header-nav-item--pageHeader {',
'  flex-grow: 1;',
'  padding: 0;',
'}',
'',
'.erp-banner {',
'  width: 100%;',
'  height: 20%;',
'}',
'',
'.erp-banner img {',
'    width: 100%;',
'    height: 20%;',
'    object-fit: scale-down;',
'}',
'</style>'))
,p_plug_display_condition_type=>'NEVER'
,p_landmark_type=>'banner'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9418598415756206)
,p_plug_name=>'let it be here'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>60
,p_location=>null
,p_plug_display_condition_type=>'NEVER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9421851551756239)
,p_plug_name=>'Project Gross Margin Reports'
,p_parent_plug_id=>wwv_flow_imp.id(9418598415756206)
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--hideHeader js-addHiddenHeadingRoleDesc'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2072724515482255512
,p_plug_display_sequence=>10
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    ''Project Gross Margin Reports'' AS CARD_TITLE,',
'    ''Analyze project profitability and financial performance.'' AS CARD_TEXT,',
'    APEX_PAGE.GET_URL(p_page => 21) AS CARD_LINK,',
'    ''fa-chart-line'' AS CARD_ICON',
'FROM DUAL',
'UNION ALL',
'SELECT',
'    ''Client Profitability'' AS CARD_TITLE,',
'    ''Analysis Project''''s report per employees .'' AS CARD_TEXT,',
'    APEX_PAGE.GET_URL(p_page => 21) AS CARD_LINK, ',
'    ''fa-database-wrench'' AS CARD_ICON',
'FROM DUAL;',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(9421972651756240)
,p_region_id=>wwv_flow_imp.id(9421851551756239)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'CARD_TITLE'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>false
,p_body_column_name=>'CARD_TEXT'
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'INITIALS'
,p_icon_class_column_name=>'CARD_ICON'
,p_icon_position=>'START'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'CARD_TITLE'
,p_pk2_column_name=>'CARD_TITLE'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(9422073507756241)
,p_card_id=>wwv_flow_imp.id(9421972651756240)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'&CARD_LINK.'
,p_link_attributes=>'&CARD_LINK.'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9564594579767806)
,p_plug_name=>'Report & Analysis'
,p_parent_plug_id=>wwv_flow_imp.id(9418598415756206)
,p_region_template_options=>'#DEFAULT#:t-Region--accent2:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9564636538767807)
,p_plug_name=>'Client Profitability Report'
,p_parent_plug_id=>wwv_flow_imp.id(9564594579767806)
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--hideHeader js-addHiddenHeadingRoleDesc'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2072724515482255512
,p_plug_display_sequence=>10
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    report_title,',
'    report_summary,',
'    report_icon,',
'    report_color,',
'    APEX_PAGE.GET_URL(p_page => report_page) AS report_link,',
'    report_help',
'FROM (',
'    SELECT ',
'        ''Project Gross Margin Report'' AS report_title,',
'        ''Analyze project-level profitability, revenue, cost, and resource efficiency.'' AS report_summary,',
'        ''fa-chart-line'' AS report_icon,',
'        ''bg-primary'' AS report_color,',
'        21 AS report_page,',
'        ''Shows financial metrics like revenue, cost, profit/loss, gross margin %, and resource count for each project.'' AS report_help',
'    FROM DUAL',
'    UNION ALL',
'    SELECT ',
'        ''Client Profitability Report'',',
'        ''Identify your most profitable clients by aggregating project-level financials.'',',
'        ''fa-handshake'',',
'        ''bg-warning'',',
'        23,',
'        ''Shows total revenue, cost, profit/loss, and gross margin % for each client.''',
'    FROM DUAL',
'    UNION ALL',
'    SELECT ',
'        ''Employee Contribution Report'',',
'        ''Evaluate employee-level profitability based on hours, cost, and revenue attribution.'',',
'        ''fa-user-tie'',',
'        ''bg-success'',',
'        25,',
'        ''Displays utilization %, billable hours, cost, and net profitability per employee.''',
'    FROM DUAL',
')',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(9564775996767808)
,p_region_id=>wwv_flow_imp.id(9564636538767807)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'REPORT_TITLE'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>false
,p_body_column_name=>'REPORT_SUMMARY'
,p_second_body_adv_formatting=>false
,p_second_body_column_name=>'REPORT_HELP'
,p_icon_source_type=>'INITIALS'
,p_icon_class_column_name=>'REPORT_ICON'
,p_icon_position=>'START'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'REPORT_TITLE'
,p_pk2_column_name=>'REPORT_TITLE'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(9564884412767809)
,p_card_id=>wwv_flow_imp.id(9564775996767808)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'&REPORT_LINK.'
,p_link_attributes=>'&REPORT_LINK.'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9565005526767811)
,p_plug_name=>'Oracle Dashboard'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="erp-banner">',
'  <img src="#APP_FILES#dashboard.png" alt="Gross Margin Calculator Dashboard">',
'</div>',
'<style>',
'.t-Header-nav {',
'  display: block;',
'}',
'',
'.t-Header-nav-item--pageHeader {',
'  flex-grow: 1;',
'  padding: 0;',
'}',
'',
'.erp-banner {',
'  width: 100%;',
'  height: 100%;',
'  padding: 5px; ',
'  box-sizing: border-box;',
'}',
'',
'.erp-banner img {',
'  width: 100%;',
'  height: 150px;',
'  object-fit: cover;',
'  /* Rounded corners */',
'  border-radius: 15px; ',
'  /* Fading shadow border */',
'  box-shadow: 0 0 10px 5px rgba(0, 0, 0, 0.5); ',
'}',
'</style>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9617240815043809)
,p_plug_name=>'Report & Analysis'
,p_region_template_options=>'#DEFAULT#:t-Region--accent2:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>40
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9616781111043804)
,p_plug_name=>'App Modules'
,p_parent_plug_id=>wwv_flow_imp.id(9617240815043809)
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--hideHeader js-addHiddenHeadingRoleDesc'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2072724515482255512
,p_plug_display_sequence=>10
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    report_title,',
'    report_summary,',
'    report_icon,',
'    APEX_PAGE.GET_URL(p_page => report_page) AS report_link,',
'    report_help',
'FROM (',
'    SELECT ',
'        ''Project Gross Margin'' AS report_title,',
'        ''Analyze project-level profitability, revenue, cost, and resource efficiency.'' AS report_summary,',
'        ''fa-chart-line'' AS report_icon,',
'        21 AS report_page,',
'        ''Shows financial metrics like revenue, cost, profit/loss, gross margin %, and resource count for each project.'' AS report_help,',
'        ''ALL'' AS allowed_roles',
'    FROM DUAL',
'    UNION ALL',
'    SELECT ',
'        ''Employee Gross Margin'',',
'        ''Identify your most profitable clients by aggregating project-level financials.'',',
'        ''fa-chart-area'',',
'        25,',
'        ''Shows total revenue, cost, profit/loss, and gross margin % for each client.'',',
'        ''RESTRICTED'' AS allowed_roles',
'    FROM DUAL',
'    UNION ALL',
'    SELECT ',
'        ''Customers Profit Analysis'',',
'        ''Identify your most profitable clients by aggregating project-level financials.'',',
'        ''fa-handshake'',',
'        23,',
'        ''Shows total revenue, cost, profit/loss, and gross margin % for each client.'',',
'        ''ALL'' AS allowed_roles',
'    FROM DUAL',
')',
'WHERE allowed_roles = ''ALL'' ',
'   OR (allowed_roles = ''RESTRICTED'' ',
'       AND EXISTS (',
'           SELECT 1',
'           FROM apex_appl_acl_user_roles',
'           WHERE user_name = :APP_USER',
'             AND role_static_id IN (''ADMINISTRATOR'', ''CONTRIBUTOR'')',
'       )',
'   )',
'',
'-- SELECT',
'--     report_title,',
'--     report_summary,',
'--     report_icon,',
'--     APEX_PAGE.GET_URL(p_page => report_page) AS report_link,',
'--     report_help',
'-- FROM (',
'--     SELECT ',
'--         ''Project Gross Margin'' AS report_title,',
'--         ''Analyze project-level profitability, revenue, cost, and resource efficiency.'' AS report_summary,',
'--         ''fa-chart-line'' AS report_icon,',
'--         21 AS report_page,',
'--         ''Shows financial metrics like revenue, cost, profit/loss, gross margin %, and resource count for each project.'' AS report_help,',
'--         ''ALL'' AS allowed_roles  -- Show to all roles',
'--     FROM DUAL',
'--     UNION ALL',
'--     SELECT ',
'--         ''Employee Gross Margin'',',
'--         ''Identify your most profitable clients by aggregating project-level financials.'',',
'--         ''fa-chart-area'',',
'--         25,',
'--         ''Shows total revenue, cost, profit/loss, and gross margin % for each client.'',',
'--         ''RESTRICTED'' AS allowed_roles  -- Hide from READER role',
'--     FROM DUAL',
'--     UNION ALL',
'--     SELECT ',
'--         ''Customers Profit Analysis'',',
'--         ''Identify your most profitable clients by aggregating project-level financials.'',',
'--         ''fa-handshake'',',
'--         23,',
'--         ''Shows total revenue, cost, profit/loss, and gross margin % for each client.'',',
'--         ''ALL'' AS allowed_roles  -- Show to all roles',
'--     FROM DUAL',
'-- )',
'-- WHERE allowed_roles = ''ALL'' ',
'--    OR (allowed_roles = ''RESTRICTED'' ',
'--        AND (APEX_ACL.HAS_USER_ROLE(p_role_static_id => ''ADMINISTRATOR'') = TRUE',
'--             OR APEX_ACL.HAS_USER_ROLE(p_role_static_id => ''CONTRIBUTOR'') = TRUE))'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(9616812731043805)
,p_region_id=>wwv_flow_imp.id(9616781111043804)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'REPORT_TITLE'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>false
,p_body_column_name=>'REPORT_SUMMARY'
,p_second_body_adv_formatting=>false
,p_second_body_column_name=>'REPORT_HELP'
,p_icon_source_type=>'INITIALS'
,p_icon_class_column_name=>'REPORT_ICON'
,p_icon_position=>'START'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'REPORT_TITLE'
,p_pk2_column_name=>'REPORT_TITLE'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(9616959499043806)
,p_card_id=>wwv_flow_imp.id(9616812731043805)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'&REPORT_LINK.'
,p_link_attributes=>'&REPORT_LINK.'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9617365189043810)
,p_plug_name=>'Oracle Data Manager '
,p_region_template_options=>'#DEFAULT#:t-Region--accent3:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>30
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9418351678756204)
,p_plug_name=>'Data Setup'
,p_title=>'Data setup'
,p_parent_plug_id=>wwv_flow_imp.id(9617365189043810)
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--hideHeader js-addHiddenHeadingRoleDesc'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2072724515482255512
,p_plug_display_sequence=>10
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    ''Import Data'' AS CARD_TITLE,',
'    ''Upload Project, Employee and their Timesheets data.'' AS CARD_TEXT,',
'    APEX_PAGE.GET_URL(p_page => 5) AS CARD_LINK,  ',
'    ''fa-database-plus'' AS CARD_ICON',
'FROM DUAL',
'WHERE EXISTS (',
'    SELECT 1 ',
'    FROM apex_appl_acl_user_roles ',
'    WHERE user_name = :APP_USER ',
'      AND role_static_id IN (''ADMINISTRATOR'', ''CONTRIBUTOR'')',
')',
'',
'UNION ALL',
'',
'SELECT',
'    ''Data Management'' AS CARD_TITLE,',
'    ''View & Manage Employee, Project, and Timesheet records.'' AS CARD_TEXT,',
'    APEX_PAGE.GET_URL(p_page => 12) AS CARD_LINK, ',
'    ''fa-database-wrench'' AS CARD_ICON',
'FROM DUAL',
'WHERE EXISTS (',
'    SELECT 1 ',
'    FROM apex_appl_acl_user_roles ',
'    WHERE user_name = :APP_USER ',
'      AND role_static_id = ''READER''',
')',
'',
'',
'-- -- SELECT',
'-- --     ''Import Data'' AS CARD_TITLE,',
'-- --     ''Upload Project, Employee and thier Timesheets data.'' AS CARD_TEXT,',
'-- --     APEX_PAGE.GET_URL(p_page => 5) AS CARD_LINK,  ',
'-- --     ''fa-database-plus'' AS CARD_ICON',
'-- -- FROM DUAL',
'-- -- UNION ALL',
'-- -- SELECT',
'-- --     ''Data Management'' AS CARD_TITLE,',
'-- --     ''View & Manage Employee, Project, and Timesheet records.'' AS CARD_TEXT,',
'-- --     APEX_PAGE.GET_URL(p_page => 12) AS CARD_LINK, ',
'-- --     ''fa-database-wrench'' AS CARD_ICON',
'-- -- FROM DUAL;',
'-- SELECT',
'--     ''Import Data'' AS CARD_TITLE,',
'--     ''Upload Project, Employee and their Timesheets data.'' AS CARD_TEXT,',
'--     APEX_PAGE.GET_URL(p_page => 5) AS CARD_LINK,  ',
'--     ''fa-database-plus'' AS CARD_ICON',
'-- FROM DUAL',
'-- WHERE APEX_ACL.HAS_USER_ROLE(p_role_static_id => ''ADMINISTRATOR'') = TRUE',
'--    OR APEX_ACL.HAS_USER_ROLE(p_role_static_id => ''CONTRIBUTOR'') = TRUE',
'',
'-- UNION ALL',
'-- SELECT',
'--     ''Data Management'' AS CARD_TITLE,',
'--     ''View & Manage Employee, Project, and Timesheet records.'' AS CARD_TEXT,',
'--     APEX_PAGE.GET_URL(p_page => 12) AS CARD_LINK, ',
'--     ''fa-database-wrench'' AS CARD_ICON',
'-- FROM DUAL',
'-- WHERE APEX_ACL.HAS_USER_ROLE(p_role_static_id => ''READER'') = TRUE',
''))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(9418484152756205)
,p_region_id=>wwv_flow_imp.id(9418351678756204)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'CARD_TITLE'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>false
,p_body_column_name=>'CARD_TEXT'
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'INITIALS'
,p_icon_class_column_name=>'CARD_ICON'
,p_icon_position=>'START'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'CARD_TITLE'
,p_pk2_column_name=>'CARD_TITLE'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(9419002378756211)
,p_card_id=>wwv_flow_imp.id(9418484152756205)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'&CARD_LINK.'
,p_link_attributes=>'&CARD_LINK.'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(9976493227752845)
,p_name=>'New'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(9976534682752846)
,p_event_id=>wwv_flow_imp.id(9976493227752845)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_name=>'m'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'JAVASCRIPT_EXPRESSION'
,p_affected_elements=>wwv_flow_string.join(wwv_flow_t_varchar2(
'console.log("APP_ROLE value:", apex.item("G_USER_ROLE").getValue());',
'',
''))
);
wwv_flow_imp.component_end;
end;
/
